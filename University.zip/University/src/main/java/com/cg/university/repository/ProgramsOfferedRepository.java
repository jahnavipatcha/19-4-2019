package com.cg.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.university.entity.ProgramsOffered;

public interface ProgramsOfferedRepository extends JpaRepository<ProgramsOffered, String>{

	

}
