package com.cg.university.entity;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name="ProgramsOffered")
public class ProgramsOffered implements Serializable{

    @Id
    @Column(name="programName")
	private String programName;
	private String description;	
	private String applicantEligibility;	
	private String duration;	
	private String degreeCertificate;
	
	@JsonIgnore
    @OneToMany(mappedBy = "programsOffered")
	private List<ProgramsScheduled> programScheduled;
	 
}
